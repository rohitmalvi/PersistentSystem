package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Supplier;
import com.example.demo.serviceImpl.SupplierServiceImple;

@RestController
@RequestMapping("/api/supplier")
public class SupplierController {

	@Autowired
	private SupplierServiceImple service;

	@GetMapping("/supplier")
	public ResponseEntity<List<Supplier>> findAllProduct() {
		List<Supplier>su= service.findAll();
		return ResponseEntity.ok().body(su);
	}

	@GetMapping("/supplier/{id}")
	public ResponseEntity<Supplier> getByid(@PathVariable("Supplier_id") Integer id) throws Exception {
		Supplier su= service.findById(id);
		return ResponseEntity.ok().body(su);

	}

	@PostMapping("/saveSupplier")
	public ResponseEntity<Supplier> saveProduct(@RequestBody Supplier supplier) {
		Supplier su= service.insert(supplier);
		return ResponseEntity.ok().body(su);

	}

	@PutMapping("/updateSupplier/{id}")
	public ResponseEntity<Supplier> updateProduct(@RequestBody Supplier supplier) {
		Supplier su= service.edit(supplier);
		return ResponseEntity.ok().body(su);

	}

	@DeleteMapping("/deleteSupplier/{id}")
	public void delteById(@PathVariable("product_id") Integer id) {
		service.deleteById(id);
	}

}
//{
//    "id": 6,
//    "firstName": null,
//    "lastName": null,
//    "email": null,
//    "address": null,
//    "contactNumber": null,
//    "productId": null,
//    "addedDate": null,
//    "modifiedDate": null
//}
