package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Customer;

public interface CustomerService {
	List<Customer> findAll();

	Customer findById(Integer id) throws Exception;

	Customer insert(Customer customer);

	Customer edit(Customer customer);

	void deleteById(Integer id);
}
