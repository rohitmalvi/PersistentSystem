package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Supplier;
import com.example.demo.repository.SupplierRepository;
import com.example.demo.service.SupplierService;

@Service
public class SupplierServiceImple implements SupplierService {
	
	@Autowired
	private SupplierRepository repository;

	@Override
	public List<Supplier> findAll() {
		// TODO Auto-generated method stub
		return  repository.findAll();
	}

	@Override
	public Supplier findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return repository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + id));

	}

	@Override
	public Supplier insert(Supplier supplier) {
		// TODO Auto-generated method stub
		return this.repository.save(supplier);
	}

	@Override
	public Supplier edit(Supplier supplier) {
		// TODO Auto-generated method stub
		return this.repository.save(supplier);
	}

	@Override
	public void deleteById(Integer id) {
		// TODO Auto-generated method stub
		this.repository.deleteById(id);
	}

	
}
