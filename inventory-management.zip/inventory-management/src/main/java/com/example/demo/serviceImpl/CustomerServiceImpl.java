package com.example.demo.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.model.Customer;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.service.CustomerService;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository repository;

	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	@Override
	public Customer findById(Integer id) throws Exception {
		// TODO Auto-generated method stub
		return repository.findById(id).
				orElseThrow(() -> new ResourceNotFoundException("User not found on :: " + id));

	}

	@Override
	public Customer insert(Customer customer) {
		// TODO Auto-generated method stub

		return this.repository.save(customer);
	}

	@Override
	public Customer edit(Customer customer) {
		// TODO Auto-generated method stub

		return this.repository.save(customer);
	}

	@Override
	public void deleteById(Integer id) {
		// TODO Auto-generated method stub
		this.repository.deleteById(id);

	}

}
