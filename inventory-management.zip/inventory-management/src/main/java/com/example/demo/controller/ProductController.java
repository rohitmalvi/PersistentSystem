package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;
import com.example.demo.serviceImpl.ProductServiceJpaImpl;

@RestController
@RequestMapping("/api/product")
public class ProductController {

	@Autowired
	private ProductServiceJpaImpl service;

	@GetMapping("/products")
	public ResponseEntity<List<Product>> findAllProduct() {
		List<Product> pr = service.findAll();
		return ResponseEntity.ok().body(pr);
	}

	@GetMapping("/product/{id}")
	public ResponseEntity<Product> getByid(@PathVariable("product_id") Integer id) throws Exception {
		Product pr = service.findById(id);
		return ResponseEntity.ok().body(pr);
	}

	@PostMapping("/saveProduct")
	public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
		Product pr = service.insert(product);
		return ResponseEntity.ok(pr);

	}

	@PutMapping("/updateProduct/{id}")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product) {
		Product pr = service.edit(product);
		return ResponseEntity.ok(pr);
	}

	@DeleteMapping("/deleteProduct/{id}")
	public void delteById(@PathVariable("product_id") Integer id) {
		service.deleteById(id);
	}

	/*
	 * {
	 * 
	 * "productName": "keyboard", "category": "hardware", "costPrice": "500000",
	 * "sellingPrice": "5555555", "quantity": 9, "status": true }
	 */

}
